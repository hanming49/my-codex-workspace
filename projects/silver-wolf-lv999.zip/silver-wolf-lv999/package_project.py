from pathlib import Path
import zipfile
root=Path(__file__).resolve().parent
target=root.parent/'silver-wolf-lv999.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if p.is_file() and 'tools' not in rel.parts and '__pycache__' not in rel.parts and p.suffix not in ('.log','.blend1'):
            archive.write(p,'silver-wolf-lv999/'+str(rel))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
print(target, target.stat().st_size)
