import bpy,math
from mathutils import Vector
from pathlib import Path
R=Path(__file__).parent;bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def M(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);return m
def U(n,l,s,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,location=l);o=bpy.context.object;o.name=n;o.scale=s;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);q=o.modifiers.new('smooth','SUBSURF');q.levels=1;return o
def C(n,l,s,m):
 bpy.ops.mesh.primitive_cube_add(location=l);o=bpy.context.object;o.name=n;o.scale=s;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);q=o.modifiers.new('soft','BEVEL');q.width=.12;q.segments=3;return o
def K(n,l,r1,r2,d,m):
 bpy.ops.mesh.primitive_cone_add(vertices=32,radius1=r1,radius2=r2,depth=d,location=l,rotation=(math.pi/2,0,0));o=bpy.context.object;o.name=n;o.data.materials.append(m);return o
nav=M('navy plush',(.08,.1,.2));cream=M('belly',(.9,.86,.77));yellow=M('feet',(.9,.55,.05));skin=M('face',(.95,.62,.58));hair=M('hair',(.03,.02,.04));eye=M('eyes',(.04,.05,.09));white=M('eye shine',(1,1,1));metal=M('metal',(.65,.68,.7));red=M('mouth',(.5,.04,.08));ground=M('ground',(.8,.82,.78))
U('body',(0,0,2.2),(2.1,1.4,2.1),nav);U('head',(0,0,5.0),(2.05,1.38,1.82),nav);U('belly',(0,-1.28,2.3),(1.4,.18,1.5),cream);U('face',(0,-1.38,5.0),(1.08,.17,.92),skin)
# hood rim and yellow side ear pieces
bpy.ops.mesh.primitive_torus_add(major_radius=1.12,minor_radius=.12,major_segments=48,location=(0,-1.32,5.02),rotation=(math.pi/2,0,0));bpy.context.object.data.materials.append(nav)
for x in [-1.18,1.18]:
 K('yellow ear',(x,-.05,6.15),.32,.08,.75,yellow)

for x in [-2.0,2.0]:
 o=U('fin',(x,0,2.8),(.7,.9,1.5),nav);o.rotation_euler[1]=(-.4 if x<0 else .4)
for x in [-.8,.8]:U('foot',(x,-.15,.3),(.7,.9,.35),yellow)
K('beak',(0,-1.55,5.0),.42,0,.6,yellow)
for x in [-.55,.55]:U('eye',(x,-1.52,5.35),(.32,.1,.38),eye);U('shine',(x-.1,-1.62,5.5),(.1,.03,.12),white)
for x,z,r in [(-1,5.9,-.5),(-.5,6.25,-.2),(0,6.4,0),(.5,6.25,.2),(1,5.9,.5)]:
 o=K('hair',(x,-1.4,z),.25,0,1.3,hair);o.rotation_euler[1]=r
U('mouth',(0,-1.53,4.58),(.25,.05,.3),red)
bpy.ops.mesh.primitive_torus_add(major_radius=1.0,minor_radius=.06,location=(0,-1.32,3.95),rotation=(math.pi/2,0,0));bpy.context.object.data.materials.append(metal)
for i in range(4):C('charm',(0,-1.45,3.35+i*.12),(.05,.05,.12),metal)
U('tail',(0,1.15,1.0),(1.1,.3,.65),nav)
bpy.ops.mesh.primitive_plane_add(size=30);bpy.context.object.data.materials.append(ground)
bpy.ops.object.light_add(type='AREA',location=(-4,-6,8));bpy.context.object.data.energy=1000;bpy.context.object.data.size=5
bpy.ops.object.camera_add(location=(7,-13,6));cam=bpy.context.object;bpy.context.scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=8;cam.rotation_euler=(Vector((0,-.2,3.4))-cam.location).to_track_quat('-Z','Y').to_euler()
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.render.resolution_x=700;s.render.resolution_y=900;s.render.image_settings.file_format='PNG';s.render.filepath=str(R/'character.png');s.world.color=(.75,.8,.9);bpy.ops.wm.save_as_mainfile(filepath=str(R/'penguin-character.blend'));bpy.ops.render.render(write_still=True);bpy.ops.object.select_all(action='SELECT');bpy.ops.export_scene.gltf(filepath=str(R/'penguin-character.glb'),export_format='GLB',use_selection=True)
