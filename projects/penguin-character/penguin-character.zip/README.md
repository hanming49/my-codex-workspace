# Penguin character · standard cartoon model

Standard cartoon Blender model based on the supplied three-view reference. Includes rounded navy plush body and head, cream belly, yellow feet and beak, side fins, eyes, layered hair spikes, necklace/charm and tail. The model is stylized and editable; the reference is not a dimensioned engineering sheet.
