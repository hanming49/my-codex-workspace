import bpy,json
from pathlib import Path
root=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(root/'card.blend'))
card=bpy.data.objects['主体平面 · 完整视差合成']
depth=max(v.co.z for v in card.data.vertices)-min(v.co.z for v in card.data.vertices)
assert depth>0
assert all(i.packed_file for i in bpy.data.images if i.source=='FILE')
assert '文字平面 · Alpha PNG' in bpy.data.objects
assert '视差 · 通用 UV / Parallax' in bpy.data.node_groups
assert '镭射 · 条带与木版花纹' in bpy.data.node_groups
assert not bpy.context.scene.cycles.use_denoising
(root/'blend-validation.json').write_text(json.dumps({'blender':bpy.app.version_string,'card_thickness':depth,'images_packed':True,'separate_typography_plane':True,'parallax_and_foil_node_groups':True,'samples':bpy.context.scene.cycles.samples,'denoising':False,'illustration_layers_not_sculpted_cat':True},indent=2))
print('Blend validation passed')
