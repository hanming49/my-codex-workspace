# NEKO // 007 · 机械猫全息闪卡

银蓝机械猫、金色装甲关节与霓虹雨夜背景。多层卡片工程包含真实卡基厚度、视差材质、镭射、星光与独立文字层；机械猫是分层插画，并非独立雕塑模型。

## 打开

- Blender 4.3.2 或兼容版本打开 `card.blend`，图片已打包。播放 1–96 帧查看转卡。
- 网页：在 `web/` 执行 `npm ci --ignore-scripts`，再执行 `node server.mjs`，使用终端提示的本机地址打开。完整交付包已包含 Three.js 依赖，可以直接启动。
- 拖动转卡，FLIP 翻面，AUTO 自动转动，SAVE 保存当前画面；下方滑杆调节镭射和景深。
- `assets/` 保存原始四层 PNG，`card-config.json` 保存卡片信息，`renders/` 保存渲染和网页截图。

## 验证与限制

已用真实 Chromium 检查模型及纹理加载、鼠标拖动、翻面、自动转动、四个滑杆、图片保存以及 390px 窄屏无横向溢出。未测试真实触屏设备。

云端 Blender 不含 OpenImageDenoise，`render_card.py` 使用 32 次采样并关闭不可用的降噪，生成正面和倾斜预览。复现渲染：`blender -b -t 5 --python render_card.py`。

素材由 image_gen 生成。轮廓图与主体存在局部偏移，故轮廓发光保持克制。网页着色与 Blender 灯光效果有所区别。
