import bpy
from pathlib import Path
root=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(root/'card.blend'))
s=bpy.context.scene
s.cycles.use_denoising=False
s.cycles.samples=32
s.render.threads_mode='FIXED'
s.render.threads=5
# Preserve readable art despite small differences in the generated contour mask.
for mat in bpy.data.materials:
    if mat.use_nodes:
        for node in mat.node_tree.nodes:
            if node.name=='限制辉光覆盖 0.018':
                node.inputs[1].default_value=0.0003
bpy.ops.wm.save_as_mainfile(filepath=str(root/'card.blend'))
for frame,name in [(25,'hero'),(49,'tilted')]:
    s.frame_set(frame)
    s.render.filepath=str(root/'renders'/(name+'.png'))
    bpy.ops.render.render(write_still=True)
