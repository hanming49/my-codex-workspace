import bpy
from mathutils import Vector
from pathlib import Path
R=Path(__file__).parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def M(n,c):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);return m
def C(n,l,s,m):
 bpy.ops.mesh.primitive_cube_add(location=l);o=bpy.context.object;o.name=n;o.scale=s;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m);b=o.modifiers.new('soft','BEVEL');b.width=.05;b.segments=3;return o
def Y(n,l,r,d,m):
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=r,depth=d,location=l);o=bpy.context.object;o.name=n;o.data.materials.append(m);return o
iv=M('ivory',(.92,.86,.73));wall=M('wall',(.88,.83,.78));wood=M('oak',(.72,.52,.3));trim=M('trim',(.9,.65,.35));sage=M('sage',(.48,.58,.48));pink=M('rose',(.85,.4,.43));blush=M('pink',(.96,.66,.66));white=M('linen',(.96,.9,.84));green=M('leaves',(.15,.4,.08));gold=M('brass',(.72,.48,.12));glass=M('glass',(.7,.88,.75));frame=M('frames',(.9,.56,.56));dark=M('dark',(.22,.12,.1))
C('floor',(0,0,-.15),(5.2,4.3,.15),iv)
for x in [i*.65-4.55 for i in range(15)]:
 for y in [i*.65-3.7 for i in range(12)]:C('plank',(x,y,.04),(.29,.29,.06),wood)
C('back wall',(0,4.1,3.2),(5.1,.12,3.35),wall);C('side wall',(5,0,3.2),(.12,4.2,3.35),wall);C('crown',(0,3.85,6.25),(5.2,.24,.25),trim);C('crown',(4.75,0,6.25),(.25,4.1,.25),trim)
C('window',(1,3.7,4),(1.5,.1,1.25),trim);C('glass',(1,3.55,4),(1.25,.03,1.02),glass);C('cross',(1,3.5,4),(.06,.04,1.05),trim);C('cross',(1,3.5,4),(1.3,.04,.06),trim)
C('headboard',(-.7,2.55,1.55),(2.3,.18,1.45),sage);C('bed',(-.6,1.2,.65),(2.25,1.7,.32),sage);C('mattress',(-.6,1.25,1.08),(2.08,1.55,.28),white);C('duvet',(-.45,.95,1.42),(2,1.25,.18),pink)
for x in [-1.35,-.45,.45]:C('pillow',(x,2.15,1.72),(.48,.38,.14),blush)
C('blanket',(-.45,.45,1.62),(2.02,.18,.16),blush)
for x in [-3.15,2]:
 C('nightstand',(x,2.2,.8),(.65,.58,.62),sage);C('drawer',(x,1.6,.85),(.45,.04,.18),blush);Y('lamp',(x,2.2,2.35),.3,.5,blush);Y('lamp base',(x,2.2,1.75),.22,.08,gold)
C('wardrobe',(3.45,3.25,2.4),(1.25,.55,2.15),sage);C('wardrobe top',(3.45,3.25,4.65),(1.38,.65,.16),sage)
for x in [2.85,4.05]:C('door',(x,2.67,2.45),(.56,.03,1.9),sage);Y('knob',(x,2.59,1.6),.06,.06,gold)
Y('rug',(.65,0,.12),1.25,.06,blush);Y('rug center',(.65,0,.16),.65,.07,white);Y('plant pot',(2.2,1.9,1.3),.42,.65,white)
for dx,dz in [(-.45,1.2),(.45,1.3),(-.2,1.6),(.2,1.7)]:C('leaf',(2.2+dx,1.9,1.65+dz),(.12,.45,.04),green)
for x,z in [(2,4.8),(2.9,4.5),(2,3.9),(2.9,3.7),(3.7,4.1)]:C('frame',(x,3.82,z),(.33,.06,.43),frame);C('art',(x,3.74,z),(.25,.025,.34),white)
bpy.ops.object.light_add(type='AREA',location=(-2,-2,8));bpy.context.object.data.energy=1100;bpy.context.object.data.size=5;bpy.ops.object.light_add(type='AREA',location=(4,-1,5));bpy.context.object.data.energy=700;bpy.context.object.data.color=(1,.55,.55);bpy.context.object.data.size=4
bpy.ops.object.camera_add(location=(-10,-12,10));cam=bpy.context.object;bpy.context.scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=12;cam.rotation_euler=(Vector((0,1.2,2.2))-cam.location).to_track_quat('-Z','Y').to_euler()
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.render.resolution_x=s.render.resolution_y=800;s.render.image_settings.file_format='PNG';s.render.filepath=str(R/'bedroom.png');s.world.color=(.8,.9,.7);bpy.ops.wm.save_as_mainfile(filepath=str(R/'pastel-bedroom.blend'));bpy.ops.render.render(write_still=True)
