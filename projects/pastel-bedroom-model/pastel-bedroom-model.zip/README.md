# Pastel Bedroom Model

基于单张参考图的可编辑 Blender 室内灰盒重建。包含墙体、地板木板、床、床品、床头柜和灯、衣柜、窗户、圆形地毯、绿植和墙面装饰画。

这是按透视推断的近似模型，不是精确测量复刻。打开 `pastel-bedroom.blend` 可继续编辑；`bedroom.png` 是当前等距视角渲染。
