# Living Room Blender Import

This is a Blender scene containing the World Labs generated living-room collision mesh imported from `0-world.glb`, plus a camera and light. It is a rough structural blockout, not a fully textured furniture model. For the full visual result use the `.spz` files in `living-room-world.zip` with the Image Blaster viewer.
