"""Bundle the viewer and all assets into a double-clickable offline HTML."""
import base64,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
web=root/'web'
cfg=json.loads((web/'card-config.json').read_text())
for key,value in cfg['assets'].items():
    file=web/value
    mime='model/gltf-binary' if file.suffix=='.glb' else 'image/png'
    cfg['assets'][key]='data:'+mime+';base64,'+base64.b64encode(file.read_bytes()).decode()
source=(web/'app.js').read_text()
source=re.sub(r"config=await fetch\('./card-config.json'\).*?;\n",'config='+json.dumps(cfg,ensure_ascii=False)+';\n',source,count=1)
(web/'standalone-entry.js').write_text(source)
try:
    subprocess.run(['npm','exec','--cache','/workspace/.cache/npm','--yes','--package=esbuild','--','esbuild','standalone-entry.js','--bundle','--minify','--format=iife','--outfile=standalone-bundle.js'],cwd=web,check=True)
    html=(web/'index.html').read_text()
    html=re.sub(r'<script type="importmap">.*?</script>','',html,flags=re.S)
    html=html.replace('<link rel="stylesheet" href="./style.css">','<style>'+(web/'style.css').read_text()+'</style>')
    js=(web/'standalone-bundle.js').read_text().replace('</script','<\\/script')
    html=html.replace('<script type="module" src="./app.js"></script>','<script>'+js+'</script>')
    html=html.replace('<html lang="en">','<html lang="zh-CN">')
    (root/'star-string-idol.html').write_text(html)
finally:
    for name in ['standalone-entry.js','standalone-bundle.js']:
        (web/name).unlink(missing_ok=True)
print('Standalone HTML created')
