import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent
errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
        args=['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    page = browser.new_page(viewport={'width': 1280, 'height': 1000}, device_scale_factor=1)
    page.on('pageerror', lambda error: errors.append(str(error)))
    if os.environ.get('CARD_URL')=='embedded':
        page.context.set_offline(True)
        page.set_content((root/'star-string-idol.html').read_text(),wait_until='load')
    else:
        page.goto(os.environ.get('CARD_URL','http://127.0.0.1:4175'), wait_until='networkidle')
    page.wait_for_function('window.__holo && window.__holo.ready', timeout=60000)
    assert page.locator('#card-title').inner_text() == '星弦歌姬'
    page.wait_for_timeout(1200)
    page.screenshot(path=str(root/'renders/web-front.png'))
    box = page.locator('#stage').bounding_box()
    page.mouse.move(box['x']+box['width']/2, box['y']+box['height']/2)
    page.mouse.down()
    page.mouse.move(box['x']+box['width']/2+80, box['y']+box['height']/2+20, steps=8)
    page.mouse.up()
    page.wait_for_timeout(900)
    page.screenshot(path=str(root/'renders/web-tilted.png'))
    page.locator('#flip').click()
    page.wait_for_function("document.querySelector('#view-label').textContent==='BACK'")
    page.wait_for_timeout(1600)
    page.screenshot(path=str(root/'renders/web-back.png'))
    page.locator('#reset').click()
    page.locator('#auto').click()
    assert page.locator('#auto').get_attribute('aria-pressed') == 'true'
    page.locator('#auto').click()
    for selector, value in [('#foil','0.8'),('#scale','1.2'),('#depth','0.35'),('#bg-depth','-0.3')]:
        page.locator(selector).evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event("input",{bubbles:true}))}', value)
    with page.expect_download() as download:
        page.locator('#save').click()
    download.value.save_as(str(root/'renders/web-saved.png'))
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(1000)
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), 'Mobile overflow'
    page.screenshot(path=str(root/'renders/web-mobile.png'), full_page=True)
    assert not errors, errors
    (root/('offline-validation.json' if os.environ.get('CARD_URL')=='embedded' else 'browser-validation.json')).write_text(json.dumps({'ready':True,'drag':True,'flip':True,'auto':True,'sliders':True,'image_save':True,'narrow_viewport_overflow':False,'page_errors':errors,'physical_touch_device_tested':False},indent=2))
    browser.close()
print('Viewer validation passed')
